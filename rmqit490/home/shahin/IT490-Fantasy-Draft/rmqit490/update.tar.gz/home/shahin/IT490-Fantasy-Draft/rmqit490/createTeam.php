<html>
	<head>
		<title>Create Team</title>
	</head>
	<body>
		<h1>
			This is a placeholder.
		</h1>
		
	</body>
</html>